Unified video package: unified_videos

Common target settings:
- Container: MP4 / QuickTime-family container
- Video codec: H.264 / AVC, codec tag avc1
- Profile/level: High, level 3.1
- Resolution: 256x256
- Pixel format: yuv420p
- Frame rate: 20 fps constant frame rate
- SAR/DAR: 1:1
- Audio: none
- Metadata/chapters: removed
- GOP/keyframe interval: 50 frames, scene-cut keyframes disabled

Notes:
- Original durations are preserved. Bitrate and frame count differ because each source has different content length.
